jQuery(document).ready(function() {
        
       
        jQuery(".wpcf7-tel").mask("(999) 999-9999");
         jQuery.validator.addMethod("lettersonly", function (value, element) {
        return this.optional(element) || /^[a-z]+$/i.test(value);
        }, "Space, Special character & digits are not allowed");
        
        jQuery.validator.addMethod("phoneUS", function (phone_number, element) {
            phone_number = phone_number.replace(/\s+/g, "");
            return this.optional(element) || phone_number.length > 9 && phone_number.match(/^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
        }, "Please enter valid phone number");

        jQuery.validator.addMethod("myEmail2", function(value, element) {
            return this.optional(element) || (/^[a-z0-9]+([-._][a-z0-9]+)*@([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,4}$/.test(value) && /^(?=.{1,64}@.{4,64}$)(?=.{6,100}$).*/.test(value));
        }, 'Please enter a valid email address');

        jQuery.validator.addMethod('filesize', function (value, element, param) {
            return this.optional(element) || (element.files[0].size <= param * 1000000)
        }, 'File size must be less than {0} MB');

         jQuery.validator.addMethod("extension", function (value, element, param) {
            param = typeof param === "string" ? param.replace(/,/g, '|') : "png|jpe?g|gif";
            return this.optional(element) || value.match(new RegExp(".(" + param + ")$", "i"));
        }, "Please enter a value with a valid extension.");
        //jQuery(".wpcf7-tel").mask("(999) 999-9999");

      
    });
    
    jQuery(document).on("click", ".applynow", function () {
    jQuery("#wpcf7-f214-o1 form.wpcf7-form").validate({
        rules: {
            "firstName": {
                required: true,
                lettersonly: true,
            },
            "lastName": {
                required: true,
                lettersonly: true,
            },
            "currentCompany": {
                required: true
            },
            "emailaddress": {
                required: true,
                myEmail2: true
            },
            "phonenumber": {
                required: true,
            },
            "resume": {
                required: true,
                extension: "pdf|doc|docx",
                filesize: 2, // 2 MB in bytes
            },
        },
        messages: {
            "firstName": {
                required: "Enter first name"
            },
            "lastName": {
                required: "Enter last name"
            },
            "currentCompany": {
                required: "Enter company name"
            },
            "emailaddress": {
                required: "Enter email address"
            },
            "phonenumber": {
                required: "Enter phone number",
            },
            "resume": {
                required: "Resume is Required",
                extension: "Allow only pdf, doc, docx",
                filesize: "File size exceeds maximum limit 2 MB.",
            },
        },
    });
});


    /*
    ** contact form validation
    */
        if (jQuery('.wpcf7-form').length) {
        $("#wpcf7-f147-o2 form.wpcf7-form").validate({
            rules: {
                "fullname": { required: true },
                "your-email": { required: true, myEmail2: true },
                "phone": { required: true }
            },
            messages: {
                "fullname": { required: "Enter full name" },
                "your-email": { required: "Enter email address" },
                "phone": { required: "Enter phone number" }
            }
        });
    }

    // Block form submit for #wpcf7-f147-o2
// Intercept CF7 submit before AJAX triggers
$('#wpcf7-f147-o2 .wpcf7-submit').off('click').on('click', function(e) {
    var $form = $(this).closest('form');

    // If validator exists and form is invalid, block CF7
    if ($form.data('validator') && !$form.valid()) {
        e.preventDefault();               // Prevent normal submit
        e.stopImmediatePropagation();     // Prevent CF7 from sending via AJAX
        return false;
    }
});


    
    jQuery.validator.addMethod("lettersonly", function (value, element) {
        return this.optional(element) || /^[a-z]+$/i.test(value);
    }, "Space, Special character & digits are not allowed");
    
    jQuery.validator.addMethod("phoneUS", function (phone_number, element) {
        phone_number = phone_number.replace(/\s+/g, "");
        return this.optional(element) || phone_number.length > 9 && phone_number.match(/^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
    }, "Please enter valid phone number");

    jQuery.validator.addMethod("myEmail2", function(value, element) {
        return this.optional(element) || (/^[a-z0-9]+([-._][a-z0-9]+)*@([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,4}$/.test(value) && /^(?=.{1,64}@.{4,64}$)(?=.{6,100}$).*/.test(value));
    }, 'Please enter a valid email address');