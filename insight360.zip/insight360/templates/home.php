<?php 
/*** Template Name: Home */
?>
<!-- Header -->
<?php get_header(); ?>


<!--Footer -->
<?php get_footer(); ?>