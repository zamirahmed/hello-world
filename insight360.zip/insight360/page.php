<?php
/**
 * The template for displaying all single posts
 *
 */

get_header();
?>

<?php
/* Start the Loop */

while ( have_posts() ) :the_post(); ?>

	<div class="wrapper">
		<div class="container">
			<?php the_content();?>
		</div>
	</div>

<?php
endwhile; // End of the loop.

get_footer();
